package com.jiowa.testdatagen.example;

import com.jiowa.testdatagen.randomizer.address.AddressRandomizer;
import com.jiowa.testdatagen.randomizer.address.CityRandomizer;
import com.jiowa.testdatagen.randomizer.person.BirthdateRandomizer;
import com.jiowa.testdatagen.randomizer.person.PersonRandomizer;
import com.jiowa.testdatagen.type.Address;
import com.jiowa.testdatagen.type.Birthdate;
import com.jiowa.testdatagen.type.City;
import com.jiowa.testdatagen.type.Person;



/**
 *  Just a small example how to generate person test data.
 */
public class TestDataGenerationExample 
{
    /*------------------------------------------------------------------------*\
     * Main program:                                                          *
    \*------------------------------------------------------------------------*/
        
    public static void main(String[] arguments)
    {
        // Compute a random person with an age between 20 and 30: 
        // (gender, first name, last name, birth date, address)
        Person person = PersonRandomizer.getInstance().getRandom(20, 30);    
            
        // Output:
        System.out.println(person);
            
        // Compute a random birthdate between 30 and 70 years of age:
        Birthdate birthdate = BirthdateRandomizer.getInstance().getRandom(30, 70);
        
        // Compute a random address (country, city, state, post code, street name, house no.)
        Address address = AddressRandomizer.getInstance().getRandom();
        
        // Compute a random city (country, city)
        City city = CityRandomizer.getInstance().getRandom();
        
        System.out.println(birthdate);
        System.out.println(address);
        System.out.println(city);
    } 
}
